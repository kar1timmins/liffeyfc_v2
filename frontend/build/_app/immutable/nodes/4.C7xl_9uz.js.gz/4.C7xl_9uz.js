import"../chunks/DsnmJJEf.js";import{i as He}from"../chunks/DZcFQkIc.js";import{c as me,f as le,a as v,p as Ke,ai as Pe,aj as We,m as k,ak as Fe,al as Xe,d as j,h as Ye,b as Ge,g as e,w as Je,$ as qe,s as u,j as l,am as Qe,n as Ze,e as c,r as i,ag as T,i as h,u as L,ah as et,an as tt}from"../chunks/C9n0oQyD.js";import{i as G}from"../chunks/CJZWwThb.js";import{I as ge,s as fe,e as J,a as m,b as D,i as Z,c as Oe}from"../chunks/BuXYHlOW.js";import{m as at,d as De,c as ee,t as M,f as q}from"../chunks/LzBhpizj.js";import{g as st,a as ot,s as Me}from"../chunks/DuJJcPaN.js";import{g as nt,p as it}from"../chunks/_GAvJiw-.js";import{X as rt}from"../chunks/C-G-ApVx.js";import{l as ve,s as he}from"../chunks/5mjx0hG3.js";function lt(U,P){const f=ve(P,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const E=[["path",{d:"m15 18-6-6 6-6"}]];ge(U,he({name:"chevron-left"},()=>f,{get iconNode(){return E},children:(g,te)=>{var F=me(),n=le(F);fe(n,P,"default",{}),v(g,F)},$$slots:{default:!0}}))}function ct(U,P){const f=ve(P,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const E=[["path",{d:"m9 18 6-6-6-6"}]];ge(U,he({name:"chevron-right"},()=>f,{get iconNode(){return E},children:(g,te)=>{var F=me(),n=le(F);fe(n,P,"default",{}),v(g,F)},$$slots:{default:!0}}))}function dt(U,P){const f=ve(P,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const E=[["path",{d:"M18 8L22 12L18 16"}],["path",{d:"M2 12H22"}]];ge(U,he({name:"move-right"},()=>f,{get iconNode(){return E},children:(g,te)=>{var F=me(),n=le(F);fe(n,P,"default",{}),v(g,F)},$$slots:{default:!0}}))}var pt=Je(j(`<meta name="description" content="Watch inspiring startup pitches from Dublin's emerging entrepreneurs. See how founders present their vision and connect with the investor community."/> <link rel="canonical" href="https://liffeyfoundersclub.com/pitch"/> <meta name="robots" content="index, follow"/> <meta property="og:type" content="website"/> <meta property="og:url" content="https://liffeyfoundersclub.com/pitch"/> <meta property="og:title" content="Startup Pitches - Liffey Founders Club"/> <meta property="og:description" content="Watch inspiring startup pitches from Dublin's emerging entrepreneurs."/> <meta property="og:image" content="https://liffeyfoundersclub.com/img/logo/Liffey_Founders_Club_Logo.png"/> <meta property="og:image:type" content="image/png"/> <meta property="og:image:width" content="1668"/> <meta property="og:image:height" content="2388"/> <meta property="og:image:alt" content="Liffey Founders Club Logo"/> <meta property="twitter:card" content="summary"/> <meta property="twitter:url" content="https://liffeyfoundersclub.com/pitch"/> <meta property="twitter:title" content="Startup Pitches - Liffey Founders Club"/> <meta property="twitter:description" content="Watch inspiring startup pitches from Dublin's emerging entrepreneurs."/> <meta property="twitter:image" content="https://liffeyfoundersclub.com/img/logo/Liffey_Founders_Club_Logo.png"/> <meta property="twitter:image:alt" content="Liffey Founders Club Logo"/> <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://liffeyfoundersclub.com/"
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": "Startup Pitches",
          "item": "https://liffeyfoundersclub.com/pitch"
        }
      ]
    }
  <\/script> <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "ItemList",
      "itemListElement": [
        {
          "@type": "VideoObject",
          "name": "Pitch by Bilal Nasrullah",
          "description": "Startup pitch from a Liffey Founders Club event.",
          "thumbnailUrl": "https://liffeyfoundersclub.com/img/event_june/image_1.jpg",
          "uploadDate": "2025-10-08",
          "contentUrl": "https://liffeyfoundersclub.com/videos/pitches/Bilal_Nasrullah.webm",
          "publisher": {
            "@type": "Organization",
            "name": "Liffey Founders Club",
            "logo": {
              "@type": "ImageObject",
              "url": "https://liffeyfoundersclub.com/img/event_june/image_1.jpg"
            }
          }
        },
        {
          "@type": "VideoObject",
          "name": "Pitch by Kanupriya Jamwal",
          "description": "Startup pitch from a Liffey Founders Club event.",
          "thumbnailUrl": "https://liffeyfoundersclub.com/img/event_june/image_4.jpg",
          "uploadDate": "2025-10-08",
          "contentUrl": "https://liffeyfoundersclub.com/videos/pitches/Kanupriya_Jamwal.webm",
          "publisher": {
            "@type": "Organization",
            "name": "Liffey Founders Club",
            "logo": {
              "@type": "ImageObject",
              "url": "https://liffeyfoundersclub.com/img/event_june/image_1.jpg"
            }
          }
        },
        {
          "@type": "VideoObject",
          "name": "Pitch by Ricardo Ionescu",
          "description": "Startup pitch from a Liffey Founders Club event.",
          "thumbnailUrl": "https://liffeyfoundersclub.com/img/event_june/image_5.jpg",
          "uploadDate": "2025-10-08",
          "contentUrl": "https://liffeyfoundersclub.com/videos/pitches/Ricardo_Ionescu.webm",
          "publisher": {
            "@type": "Organization",
            "name": "Liffey Founders Club",
            "logo": {
              "@type": "ImageObject",
              "url": "https://liffeyfoundersclub.com/img/event_june/image_1.jpg"
            }
          }
        },
        {
          "@type": "VideoObject",
          "name": "Pitch by Toby Steele",
          "description": "Startup pitch from a Liffey Founders Club event.",
          "thumbnailUrl": "https://liffeyfoundersclub.com/img/event_june/image_6.jpg",
          "uploadDate": "2025-10-08",
          "contentUrl": "https://liffeyfoundersclub.com/videos/pitches/Toby_Steele.webm",
          "publisher": {
            "@type": "Organization",
            "name": "Liffey Founders Club",
            "logo": {
              "@type": "ImageObject",
              "url": "https://liffeyfoundersclub.com/img/event_june/image_1.jpg"
            }
          }
        },
        {
          "@type": "VideoObject",
          "name": "Pitch by Vishranth",
          "description": "Startup pitch from a Liffey Founders Club event.",
          "thumbnailUrl": "https://liffeyfoundersclub.com/img/event_june/image_7.jpg",
          "uploadDate": "2025-10-08",
          "contentUrl": "https://liffeyfoundersclub.com/videos/pitches/Vishranth.webm",
          "publisher": {
            "@type": "Organization",
            "name": "Liffey Founders Club",
            "logo": {
              "@type": "ImageObject",
              "url": "https://liffeyfoundersclub.com/img/event_june/image_1.jpg"
            }
          }
        }
      ]
    }
  <\/script>`,1)),ut=j('<div class="absolute rounded-full glass-subtle animate-pulse transition-all duration-1000 ease-out"></div>'),mt=j('<div class="absolute inset-0 pointer-events-none"></div>'),gt=j('<button class="relative w-full h-full rounded-lg overflow-hidden bg-base-200/60 focus:outline-none hover:shadow-lg transition-shadow"><div style="transition: opacity 0.3s ease;"></div> <img decoding="async"/></button>'),ft=j('<button><div style="transition: opacity 0.3s ease;"></div> <img decoding="async"/></button>'),vt=j('<button class="relative w-full h-full rounded-lg overflow-hidden bg-base-200/60 focus:outline-none hover:shadow-lg transition-shadow"><div style="transition: opacity 0.3s ease;"></div> <img loading="lazy" decoding="async"/></button>'),ht=j('<button><div style="transition: opacity 0.3s ease;"></div> <img loading="lazy" decoding="async"/></button>'),bt=j(`<div><section class="py-16 px-4 max-w-6xl mx-auto relative overflow-hidden"><!> <div class="text-center mb-10 relative z-10"><h1 class="text-5xl md:text-6xl font-extrabold mb-4 tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent drop-shadow-lg">Dublin Startup Pitches</h1> <h2 class="text-2xl md:text-3xl font-bold text-base-content/80">Visualize Your Pitch: See How Dublin Entrepreneurs Present Their Vision</h2> <p class="mt-4 text-lg text-base-content/70 max-w-2xl mx-auto">Explore inspiring startup pitches from Dublin's emerging entrepreneurs. Watch how founders capture attention, showcase their vision, and connect with the investor community at Liffey Founders Club quarterly events.</p></div> <div class="relative w-full h-[60vh] md:h-[640px]" role="region" aria-label="Pitch image mosaic"><div class="absolute inset-0 overflow-hidden p-2 md:p-3"><div class="md:hidden grid grid-cols-2 gap-2 w-full h-full auto-rows-fr"></div> <div class="hidden md:grid grid-cols-4 grid-rows-3 gap-3 w-full h-full"></div></div></div> <div class="mt-16 pt-12 border-t border-base-200"><div class="relative w-full h-[60vh] md:h-[900px]" role="region" aria-label="September event gallery"><div class="absolute inset-0 overflow-hidden p-2 md:p-3"><div class="md:hidden grid grid-cols-2 gap-2 w-full h-full auto-rows-fr"></div> <div class="hidden md:grid grid-cols-4 grid-rows-4 gap-3 w-full h-full"></div></div></div></div> <div class="mt-8 mb-12 flex justify-center"><button class="btn glass-subtle btn-neon-accent px-8 py-3 rounded-full text-lg font-semibold shadow-lg flex items-center gap-2 transition-transform transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-accent/50">Get Investor Ready</button></div></section></div>`),yt=j('<div class="absolute inset-0 flex items-center justify-center bg-base-200/30 backdrop-blur-sm"><div class="flex flex-col items-center gap-3"><div class="loading loading-spinner loading-lg text-primary"></div> <span class="text-sm text-base-content/70">Loading image...</span></div></div>'),_t=j('<img class="w-full h-full object-contain select-none" draggable="false"/>'),wt=j('<div class="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-lg" role="dialog" aria-modal="true" aria-label="Image viewer" tabindex="0"><div class="relative w-[94vw] md:w-[90vw] max-w-6xl aspect-video md:max-h-[85vh] glass-elevated rounded-3xl shadow-2xl overflow-hidden flex items-center justify-center backdrop-blur-xl border border-white/20"><!> <button class="absolute btn btn-sm md:btn-md glass-subtle border-0 hover:bg-base-100/30 z-10" style="top:max(env(safe-area-inset-top),0.75rem);right:max(env(safe-area-inset-right),0.75rem)" aria-label="Close"><!></button> <button class="absolute left-2 md:left-4 top-1/2 -translate-y-1/2 btn btn-circle glass-subtle border-0 shadow-lg hover:bg-base-100/30 z-10 transition-all duration-200" aria-label="Previous image"><!></button> <button class="absolute right-2 md:right-4 top-1/2 -translate-y-1/2 btn btn-circle glass-subtle border-0 shadow-lg hover:bg-base-100/30 z-10 transition-all duration-200" aria-label="Next image"><!></button> <div class="absolute bottom-3 md:bottom-4 left-1/2 -translate-x-1/2 px-4 py-2 bg-black/40 backdrop-blur-sm rounded-full text-xs md:text-sm text-white font-medium"> </div> <!></div></div>'),xt=j('<video autoplay loop playsinline="" class="absolute top-0 left-0 h-full w-1/5 object-cover brightness-75 blur-[2px] shadow-xl rounded-none transition-opacity duration-[1600ms] ease-in-out"><source type="video/webm"/> <source type="video/mp4"/></video>',2),jt=j('<div class="min-h-[100dvh] md:min-h-screen flex items-center justify-center relative overflow-hidden"><div class="absolute inset-0 w-full h-full flex items-stretch justify-stretch pointer-events-none select-none z-0"></div> <section id="event-stats" class="py-10 md:py-16 px-4 max-w-3xl w-full glass-subtle rounded-3xl flex flex-col items-center relative z-10 text-base-content"><h3 class="text-xl md:text-3xl font-bold mb-6 md:mb-8 text-center">Event Highlights</h3> <div class="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-8 w-full"><div class="flex flex-col items-center"><span class="text-4xl md:text-5xl font-extrabold text-primary">500+</span> <span class="mt-1 md:mt-2 text-base md:text-lg">Attendees</span></div> <div class="flex flex-col items-center"><span class="text-4xl md:text-5xl font-extrabold text-primary">40+</span> <span class="mt-1 md:mt-2 text-base md:text-lg">Businesses Pitched</span></div> <div class="flex flex-col items-center col-span-2 md:col-span-1"><span class="text-4xl md:text-5xl font-extrabold text-primary">10+</span> <span class="mt-1 md:mt-2 text-base md:text-lg">Investors Attended</span></div></div> <div class="flex justify-center mt-6 md:mt-8"><button class="btn glass-subtle btn-neon-cool px-8 py-3 rounded-full text-lg font-semibold shadow-lg flex items-center gap-2 transition-transform transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-primary/50">Learn More <!></button></div></section></div>'),$t=j("<!> <!> <!>",1);function Mt(U,P){Ke(P,!1);const f=["/img/event_june/image_1.jpg","/img/event_june/image_4.jpg","/img/event_june/image_5.jpg","/img/event_june/image_6.jpg","/img/event_june/image_7.jpg","/img/event_june/image_8.jpg","/img/event_june/image_9.jpg","/img/event_june/image_10.jpg","/img/event_june/image_11.jpg"],E=["/img/sept_event/image_1.jpg","/img/sept_event/image_2.jpg","/img/sept_event/image_3.jpg","/img/sept_event/image_4.jpg","/img/sept_event/image_5.jpg","/img/sept_event/image_6.jpg","/img/sept_event/image_7.jpg","/img/sept_event/image_8.jpg","/img/sept_event/image_9.jpg","/img/sept_event/image_10.jpg","/img/sept_event/image_11.jpg","/img/sept_event/image_12.jpg","/img/sept_event/image_13.jpg","/img/sept_event/pitch_1.jpeg"],g=[...f,...E],te=["col-span-2 row-span-1","col-span-1 row-span-1","col-span-1 row-span-1","col-span-1 row-span-1","col-span-1 row-span-2","col-span-2 row-span-1","col-span-1 row-span-1","col-span-1 row-span-1","col-span-1 row-span-1"],F=["col-span-2 row-span-1","col-span-1 row-span-1","col-span-1 row-span-1","col-span-1 row-span-1","col-span-1 row-span-1","col-span-2 row-span-1","col-span-1 row-span-1","col-span-2 row-span-1","col-span-1 row-span-1","col-span-1 row-span-1","col-span-1 row-span-1","col-span-1 row-span-1","col-span-1 row-span-1"];let n=k(new Set);function Ee(){g.slice(0,3).forEach((o,b)=>{const w=new Image;w.onload=()=>{e(n).add(b),l(n,e(n))},w.src=o}),setTimeout(()=>{g.slice(3).forEach((o,b)=>{const w=new Image;w.onload=()=>{e(n).add(b+3),l(n,e(n)),e(n).size,g.length},w.src=o})},300)}let be=k(!0),K=k(!1),ye=!1;const[_e,we]=at(()=>ye,{duration:De.crossfade+180,fallbackDuration:De.fast,easing:ee});Pe(()=>{ye=!0,Ee(),Te(),$e()}),We(()=>{ue&&cancelAnimationFrame(ue)});async function Ne(){l(K,!0),await tt(),l(be,!1)}async function xe(){try{await it("/learnMore")}catch{}}let je=k(!1),ce=k("");function Ve(s){l(je,!0),l(ce,s),l(K,!1)}let W=k(!1),N=k(0),I=k(!1);function ae(s){l(N,s),l(I,!1);const o=new Image;o.onload=()=>{l(W,!0),l(I,!0)},o.src=g[s]}function se(){l(W,!1)}function de(){l(I,!1);const s=(e(N)+1)%g.length,o=new Image;o.onload=()=>{l(N,s),l(I,!0)},o.src=g[s]}function pe(){l(I,!1);const s=(e(N)-1+g.length)%g.length,o=new Image;o.onload=()=>{l(N,s),l(I,!0)},o.src=g[s]}let oe=k([]),ue;function Te(){l(oe,st(15))}function $e(){l(oe,ot(e(oe))),ue=requestAnimationFrame($e)}function Le(s){e(W)&&(s.key==="Escape"?(s.preventDefault(),se()):s.key==="ArrowRight"?(s.preventDefault(),de()):s.key==="ArrowLeft"&&(s.preventDefault(),pe()))}let ke=k(0),Ie=k(0);Pe(()=>(window.addEventListener("keydown",Le),()=>window.removeEventListener("keydown",Le)));const ne=["Bilal_Nasrullah","Kanupriya_Jamwal","Ricardo_Ionescu","Toby_Steele","Vishranth"];let Q=k(Array(ne.length).fill(!1));Fe(()=>e(W),()=>{try{e(W)?document.body.classList.add("overflow-hidden"):document.body.classList.remove("overflow-hidden")}catch{}}),Fe(()=>e(K),()=>{if(e(K)){l(Q,Array(ne.length).fill(!1));for(let s=0;s<ne.length;s++)setTimeout(()=>Qe(Q,e(Q)[s]=!0),s*1600)}}),Xe(),He();var Ce=$t();Ye(s=>{var o=pt();qe.title="Startup Pitches - Liffey Founders Club | Dublin Entrepreneur Showcase",Ze(38),v(s,o)});var Se=le(Ce);{var Ue=s=>{var o=bt(),b=c(o),w=c(b);{var X=p=>{var _=mt();J(_,5,()=>e(oe),t=>t.id,(t,a)=>{var x=ut();T(()=>Oe(x,`
                left: ${e(a),L(()=>e(a).x)??""}%; 
                top: ${e(a),L(()=>e(a).y)??""}%; 
                width: ${e(a),L(()=>e(a).size)??""}px; 
                height: ${e(a),L(()=>e(a).size)??""}px;
                animation-delay: ${e(a),L(()=>e(a).animationDelay)??""}s;
                transform: translate(-50%, -50%);
                opacity: ${e(a),L(()=>e(a).opacity)??""};
              `)),v(t,x)}),i(_),v(p,_)};G(w,p=>{e(K)||p(X)})}var y=u(w,4),Y=c(y),C=c(Y);J(C,5,()=>L(()=>g.slice(0,9)),Z,(p,_,t)=>{var a=gt();m(a,"aria-label",`Open image ${t+1}`);var x=c(a);let S;var r=u(x,2);m(r,"alt",`Pitch event photo ${t+1}`);let z;m(r,"loading",t<3?"eager":"lazy"),m(r,"fetchpriority",t===0?"high":"auto"),i(a),T((B,H)=>{S=D(x,1,"absolute inset-0 bg-gradient-to-br from-base-300 to-base-200 animate-pulse",null,S,B),m(r,"src",e(_)),z=D(r,1,"absolute inset-0 w-full h-full object-cover transition-opacity duration-300",null,z,H)},[()=>({"opacity-0":e(n).has(t),"opacity-100":!e(n).has(t)}),()=>({"opacity-0":!e(n).has(t),"opacity-100":e(n).has(t)})]),M(1,r,()=>q,()=>({duration:420,delay:Math.min(t*50,500),easing:ee})),h("click",a,()=>ae(t)),v(p,a)}),i(C);var A=u(C,2);J(A,5,()=>L(()=>g.slice(0,9)),Z,(p,_,t)=>{var a=ft();m(a,"aria-label",`Open image ${t+1}`);var x=c(a);let S;var r=u(x,2);m(r,"alt",`Pitch event photo ${t+1}`);let z;m(r,"loading",t<3?"eager":"lazy"),m(r,"fetchpriority",t===0?"high":"auto"),i(a),T((B,H)=>{D(a,1,`relative w-full h-full rounded-lg overflow-hidden bg-base-200/60 ${L(()=>te[t])??""} focus:outline-none hover:shadow-xl transition-shadow`),S=D(x,1,"absolute inset-0 bg-gradient-to-br from-base-300 to-base-200 animate-pulse",null,S,B),m(r,"src",e(_)),z=D(r,1,"absolute inset-0 w-full h-full object-cover transition-opacity duration-300",null,z,H)},[()=>({"opacity-0":e(n).has(t),"opacity-100":!e(n).has(t)}),()=>({"opacity-0":!e(n).has(t),"opacity-100":e(n).has(t)})]),M(1,r,()=>q,()=>({duration:520,delay:Math.min(t*60,600),easing:ee})),h("click",a,()=>ae(t)),v(p,a)}),i(A),i(Y),i(y);var $=u(y,2),O=c($),V=c(O),R=c(V);J(R,5,()=>E,Z,(p,_,t)=>{var a=vt();m(a,"aria-label",`Open September image ${t+1}`);var x=c(a);let S;var r=u(x,2);m(r,"alt",`September event photo ${t+1}`);let z;i(a),T((B,H)=>{S=D(x,1,"absolute inset-0 bg-gradient-to-br from-base-300 to-base-200 animate-pulse",null,S,B),m(r,"src",e(_)),z=D(r,1,"absolute inset-0 w-full h-full object-cover transition-opacity duration-300",null,z,H)},[()=>({"opacity-0":e(n).has(f.length+t),"opacity-100":!e(n).has(f.length+t)}),()=>({"opacity-0":!e(n).has(f.length+t),"opacity-100":e(n).has(f.length+t)})]),M(1,r,()=>q,()=>({duration:420,delay:Math.min(t*50,500),easing:ee})),h("click",a,()=>ae(f.length+t)),v(p,a)}),i(R);var ie=u(R,2);J(ie,5,()=>E,Z,(p,_,t)=>{var a=ht();m(a,"aria-label",`Open September image ${t+1}`);var x=c(a);let S;var r=u(x,2);m(r,"alt",`September event photo ${t+1}`);let z;i(a),T((B,H)=>{D(a,1,`relative w-full h-full rounded-lg overflow-hidden bg-base-200/60 ${L(()=>F[t])??""} focus:outline-none hover:shadow-xl transition-shadow`),S=D(x,1,"absolute inset-0 bg-gradient-to-br from-base-300 to-base-200 animate-pulse",null,S,B),m(r,"src",e(_)),z=D(r,1,"absolute inset-0 w-full h-full object-cover transition-opacity duration-300",null,z,H)},[()=>({"opacity-0":e(n).has(f.length+t),"opacity-100":!e(n).has(f.length+t)}),()=>({"opacity-0":!e(n).has(f.length+t),"opacity-100":e(n).has(f.length+t)})]),M(1,r,()=>q,()=>({duration:520,delay:Math.min(t*60,600),easing:ee})),h("click",a,()=>ae(f.length+t)),v(p,a)}),i(ie),i(V),i(O),i($);var re=u($,2),d=c(re);i(re),i(b),i(o),h("click",d,Ne),M(2,o,()=>_e,()=>({key:"pitch-sect"})),M(1,o,()=>we,()=>({key:"pitch-sect"})),v(s,o)};G(Se,s=>{e(be)&&s(Ue)})}var ze=u(Se,2);{var Ae=s=>{var o=wt(),b=c(o),w=c(b);{var X=d=>{var p=yt();v(d,p)};G(w,d=>{e(I)||d(X)})}var y=u(w,2),Y=c(y);rt(Y,{class:"h-5 w-5"}),i(y);var C=u(y,2),A=c(C);lt(A,{class:"h-7 w-7"}),i(C);var $=u(C,2),O=c($);ct(O,{class:"h-7 w-7"}),i($);var V=u($,2),R=c(V);i(V);var ie=u(V,2);{var re=d=>{var p=_t();T(()=>{m(p,"src",(e(N),L(()=>g[e(N)]))),m(p,"alt",`Image ${e(N)+1}`)}),M(3,p,()=>q,()=>({duration:300})),v(d,p)};G(ie,d=>{e(I)&&d(re)})}i(b),i(o),T(()=>{y.disabled=!e(I),C.disabled=!e(I),$.disabled=!e(I),et(R,`${e(N)+1} / ${L(()=>g.length)??""}`)}),h("click",y,se),h("click",C,Me(pe)),h("click",$,Me(de)),h("touchstart",b,d=>{d.touches?.length&&(l(ke,d.touches[0].clientX),l(Ie,d.touches[0].clientY))}),h("touchend",b,d=>{const p=d.changedTouches?.[0];if(!p)return;const _=p.clientX-e(ke),t=p.clientY-e(Ie);Math.abs(_)>40&&Math.abs(_)>Math.abs(t)&&(_<0?de():pe())}),h("click",o,d=>{d.currentTarget===d.target&&se()}),h("keydown",o,d=>{(d.key==="Enter"||d.key===" ")&&(d.preventDefault(),se())}),M(3,o,()=>q,()=>({duration:200})),v(s,o)};G(ze,s=>{e(W)&&s(Ae)})}var Re=u(ze,2);{var Be=s=>{var o=jt(),b=c(o);J(b,5,()=>ne,Z,(C,A,$)=>{var O=xt();O.muted=!0;var V=c(O),R=u(V,2);i(O),T(()=>{Oe(O,`left:calc(20% * ${$});opacity:${e(Q),L(()=>e(Q)[$]?1:0)??""};z-index:${$+1};`),m(V,"src",`/videos/pitches/${e(A)}.webm`),m(R,"src",`/videos/pitches/${e(A)}.mp4`)}),v(C,O)}),i(b);var w=u(b,2),X=u(c(w),4),y=c(X),Y=u(c(y));dt(Y,{class:"h-5 w-5 ml-2"}),i(y),i(X),i(w),i(o),h("mouseenter",y,xe),h("touchstart",y,xe),h("click",y,()=>Ve("/learnMore")),M(2,o,()=>_e,()=>({key:"pitch-sect"})),M(1,o,()=>we,()=>({key:"pitch-sect"})),h("outroend",o,()=>{e(je)&&e(ce)&&nt(e(ce))}),v(s,o)};G(Re,s=>{e(K)&&s(Be)})}v(U,Ce),Ge()}export{Mt as component};
