import{l as o,b as r}from"../chunks/5iQ3bF2_.js";export{o as load_css,r as start};
