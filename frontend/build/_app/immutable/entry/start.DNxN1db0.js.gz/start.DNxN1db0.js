import{l as o,b as r}from"../chunks/Bne8HhrS.js";export{o as load_css,r as start};
