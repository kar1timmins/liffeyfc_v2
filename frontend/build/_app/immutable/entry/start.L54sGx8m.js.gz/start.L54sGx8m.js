import{l as o,b as r}from"../chunks/2Od69_eb.js";export{o as load_css,r as start};
