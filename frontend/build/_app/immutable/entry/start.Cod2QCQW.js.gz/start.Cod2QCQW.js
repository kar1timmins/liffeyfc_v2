import{l as o,b as r}from"../chunks/BA7hE4uB.js";export{o as load_css,r as start};
