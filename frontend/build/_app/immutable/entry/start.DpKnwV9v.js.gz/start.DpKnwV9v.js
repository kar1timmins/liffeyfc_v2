import{l as o,b as r}from"../chunks/CXVuvDv_.js";export{o as load_css,r as start};
