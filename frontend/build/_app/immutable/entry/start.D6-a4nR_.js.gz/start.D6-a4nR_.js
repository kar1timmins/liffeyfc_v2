import{l as o,b as r}from"../chunks/BFQWTrOo.js";export{o as load_css,r as start};
