import{l as o,b as r}from"../chunks/C5mKu8zo.js";export{o as load_css,r as start};
