import{l as o,b as r}from"../chunks/BW4PLX1I.js";export{o as load_css,r as start};
