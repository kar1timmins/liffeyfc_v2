import{l as o,b as r}from"../chunks/BouFZ2PB.js";export{o as load_css,r as start};
