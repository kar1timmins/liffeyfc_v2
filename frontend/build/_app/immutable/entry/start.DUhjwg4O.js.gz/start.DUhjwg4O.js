import{l as o,b as r}from"../chunks/BVovhZoa.js";export{o as load_css,r as start};
