import"./ZGqzfwer.js";import"./IHnWUpZq.js";import{c as n,f as p,a as c}from"./Bb_-avhR.js";import{I as l,s as m}from"./Dzp_YKys.js";import{l as d,s as $}from"./DLV7x59E.js";function x(s,t){const r=d(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const a=[["rect",{width:"20",height:"16",x:"2",y:"4",rx:"2"}],["path",{d:"m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"}]];l(s,$({name:"mail"},()=>r,{get iconNode(){return a},children:(e,f)=>{var o=n(),i=p(o);m(i,t,"default",{}),c(e,o)},$$slots:{default:!0}}))}export{x as M};
