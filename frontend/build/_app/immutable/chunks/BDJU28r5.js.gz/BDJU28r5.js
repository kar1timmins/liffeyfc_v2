import"./BT0Mk-16.js";import"./MwLj0ZX1.js";import{c as p,f as i,a as c}from"./Bz0NnxOM.js";import{I as d,s as m}from"./BMb5MgyG.js";import{l,s as $}from"./BeeSttc2.js";function x(s,o){const r=l(o,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const e=[["path",{d:"M18 6 6 18"}],["path",{d:"m6 6 12 12"}]];d(s,$({name:"x"},()=>r,{get iconNode(){return e},children:(a,f)=>{var t=p(),n=i(t);m(n,o,"default",{}),c(a,t)},$$slots:{default:!0}}))}export{x as X};
