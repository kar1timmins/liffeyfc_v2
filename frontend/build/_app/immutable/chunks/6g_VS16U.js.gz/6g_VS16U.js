import"./zmOJ99P4.js";import"./Frb5Ag-Q.js";import{c as p,f as i,a as l}from"./CGao3W-y.js";import{I as d,s as c}from"./C3tvnu8z.js";import{l as m,s as $}from"./9BxiYDUt.js";function x(o,t){const s=m(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const e=[["path",{d:"M15 3h6v6"}],["path",{d:"M10 14 21 3"}],["path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"}]];d(o,$({name:"external-link"},()=>s,{get iconNode(){return e},children:(r,f)=>{var a=p(),n=i(a);c(n,t,"default",{}),l(r,a)},$$slots:{default:!0}}))}export{x as E};
