import"./DHVO9r3F.js";import"./DnyFqRxc.js";import{c as p,f as i,a as c}from"./C8IUzXpm.js";import{I as d,s as m}from"./BBjR1Cr7.js";import{l,s as $}from"./DIcIW5wK.js";function x(s,o){const r=l(o,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const e=[["path",{d:"M18 6 6 18"}],["path",{d:"m6 6 12 12"}]];d(s,$({name:"x"},()=>r,{get iconNode(){return e},children:(a,f)=>{var t=p(),n=i(t);m(n,o,"default",{}),c(a,t)},$$slots:{default:!0}}))}export{x as X};
