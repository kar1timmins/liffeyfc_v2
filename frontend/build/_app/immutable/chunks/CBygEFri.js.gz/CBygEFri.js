import"./ysFNrJwE.js";import"./B8CD1KcD.js";import{c as i,f as c,a as l}from"./XOVz1ozu.js";import{I as d,s as $}from"./BRBS2ul5.js";import{l as p,s as h}from"./B_K3siRU.js";function y(o,e){const n=p(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const a=[["line",{x1:"12",x2:"12",y1:"2",y2:"22"}],["path",{d:"M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"}]];d(o,h({name:"dollar-sign"},()=>n,{get iconNode(){return a},children:(s,f)=>{var t=i(),r=c(t);$(r,e,"default",{}),l(s,t)},$$slots:{default:!0}}))}function x(o,e){const n=p(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const a=[["circle",{cx:"12",cy:"12",r:"10"}],["path",{d:"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"}],["path",{d:"M2 12h20"}]];d(o,h({name:"globe"},()=>n,{get iconNode(){return a},children:(s,f)=>{var t=i(),r=c(t);$(r,e,"default",{}),l(s,t)},$$slots:{default:!0}}))}function N(o,e){const n=p(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const a=[["path",{d:"M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"}],["rect",{width:"4",height:"12",x:"2",y:"9"}],["circle",{cx:"4",cy:"4",r:"2"}]];d(o,h({name:"linkedin"},()=>n,{get iconNode(){return a},children:(s,f)=>{var t=i(),r=c(t);$(r,e,"default",{}),l(s,t)},$$slots:{default:!0}}))}export{y as D,x as G,N as L};
