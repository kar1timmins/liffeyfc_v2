import"./C8VEYMcy.js";import"./BLC6gTr2.js";import{c as d,f as p,a as i}from"./DQfm0XhG.js";import{I as c,s as l}from"./D5c3ELo5.js";import{l as m,s as h}from"./CRS16C6X.js";function x(r,t){const e=m(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const o=[["path",{d:"M8 2v4"}],["path",{d:"M16 2v4"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2"}],["path",{d:"M3 10h18"}]];c(r,h({name:"calendar"},()=>e,{get iconNode(){return o},children:(s,$)=>{var a=d(),n=p(a);l(n,t,"default",{}),i(s,a)},$$slots:{default:!0}}))}export{x as C};
