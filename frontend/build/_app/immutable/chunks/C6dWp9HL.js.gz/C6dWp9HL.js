import"./C8VEYMcy.js";import"./BLC6gTr2.js";import{c as n,f as i,a as p}from"./DQfm0XhG.js";import{I as l,s as m}from"./CtSAQaHW.js";import{l as d,s as $}from"./CRS16C6X.js";function y(o,r){const e=d(r,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const t=[["circle",{cx:"11",cy:"11",r:"8"}],["path",{d:"m21 21-4.3-4.3"}]];l(o,$({name:"search"},()=>e,{get iconNode(){return t},children:(a,f)=>{var s=n(),c=i(s);m(c,r,"default",{}),p(a,s)},$$slots:{default:!0}}))}export{y as S};
