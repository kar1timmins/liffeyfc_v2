import"./CdtDFVDF.js";import"./DNeaHKK6.js";import{c as l,f as p,a as i}from"./nDAxfqvr.js";import{I as c,a as d}from"./DfWLTygy.js";import{l as m,b as $}from"./o_fySH2a.js";function y(o,a){const e=m(a,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const s=[["path",{d:"M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1"}],["path",{d:"M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4"}]];c(o,$({name:"wallet"},()=>e,{get iconNode(){return s},children:(r,f)=>{var t=l(),n=p(t);d(n,a,"default",{}),i(r,t)},$$slots:{default:!0}}))}export{y as W};
