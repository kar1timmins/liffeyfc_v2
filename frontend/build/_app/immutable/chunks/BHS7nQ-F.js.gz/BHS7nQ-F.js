import"./DbnszChQ.js";import"./CDi1VXXQ.js";import{c as n,f as l,a as i}from"./CqZwQSuo.js";import{I as d,s as $}from"./ClQQPn8a.js";import{l as p,s as m}from"./B1ZLS_ja.js";function y(r,e){const s=p(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const o=[["path",{d:"M5 12h14"}],["path",{d:"M12 5v14"}]];d(r,m({name:"plus"},()=>s,{get iconNode(){return o},children:(a,f)=>{var t=n(),c=l(t);$(c,e,"default",{}),i(a,t)},$$slots:{default:!0}}))}function x(r,e){const s=p(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const o=[["circle",{cx:"12",cy:"12",r:"10"}],["circle",{cx:"12",cy:"12",r:"6"}],["circle",{cx:"12",cy:"12",r:"2"}]];d(r,m({name:"target"},()=>s,{get iconNode(){return o},children:(a,f)=>{var t=n(),c=l(t);$(c,e,"default",{}),i(a,t)},$$slots:{default:!0}}))}export{y as P,x as T};
