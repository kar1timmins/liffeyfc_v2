import"./ysFNrJwE.js";import"./B8CD1KcD.js";import{c as i,f as n,a as l}from"./XOVz1ozu.js";import{I as p,s as m}from"./BRBS2ul5.js";import{l as d,s as $}from"./B_K3siRU.js";function h(t,r){const o=d(r,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const s=[["circle",{cx:"12",cy:"12",r:"10"}],["circle",{cx:"12",cy:"12",r:"6"}],["circle",{cx:"12",cy:"12",r:"2"}]];p(t,$({name:"target"},()=>o,{get iconNode(){return s},children:(c,f)=>{var e=i(),a=n(e);m(a,r,"default",{}),l(c,e)},$$slots:{default:!0}}))}export{h as T};
