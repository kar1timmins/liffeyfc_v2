import"./DcKgRf5s.js";import"./Cljqr8YE.js";import{c as l,f as p,a as i}from"./pJbLid0C.js";import{I as c,a as d}from"./Clg_0GN6.js";import{l as m,b as $}from"./DQinkebW.js";function y(o,a){const e=m(a,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const s=[["path",{d:"M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1"}],["path",{d:"M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4"}]];c(o,$({name:"wallet"},()=>e,{get iconNode(){return s},children:(r,f)=>{var t=l(),n=p(t);d(n,a,"default",{}),i(r,t)},$$slots:{default:!0}}))}export{y as W};
